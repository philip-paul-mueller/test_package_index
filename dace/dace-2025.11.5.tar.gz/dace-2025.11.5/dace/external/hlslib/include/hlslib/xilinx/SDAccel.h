/// @author    Johannes de Fine Licht (definelicht@inf.ethz.ch)
/// @copyright This software is copyrighted under the BSD 3-Clause License.

#pragma once

#warning "This header has been deprecated in favor of <hlslib/xilinx/OpenCL.h>."

#include "OpenCL.h"
