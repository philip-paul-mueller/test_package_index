# Copyright 2019-2021 ETH Zurich and the DaCe authors. All rights reserved.
from .einsum import create_einsum_sdfg
