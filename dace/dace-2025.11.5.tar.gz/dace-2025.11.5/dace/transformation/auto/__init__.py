# Copyright 2019-2021 ETH Zurich and the DaCe authors. All rights reserved.
""" This module initializes the auto-optimization transformations package."""
