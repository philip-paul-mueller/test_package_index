// Copyright 2019-2021 ETH Zurich and the DaCe authors. All rights reserved.
#pragma once

#pragma OPENCL EXTENSION cl_intel_channels : enable

#include "dace/intel_fpga/math.h"
