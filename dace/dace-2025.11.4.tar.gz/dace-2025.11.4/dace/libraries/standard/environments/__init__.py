# Copyright 2019-2023 ETH Zurich and the DaCe authors. All rights reserved.
from .cuda import CUDA
from .hptt import HPTT
